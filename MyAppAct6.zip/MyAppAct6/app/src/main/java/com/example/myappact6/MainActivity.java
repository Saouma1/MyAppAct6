package com.example.myappact6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editTextWidth, editTextLength;
    Button buttonShowResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextWidth = findViewById(R.id.editTextWidth);
        editTextLength = findViewById(R.id.editTextLength);
        buttonShowResult = findViewById(R.id.buttonShowResult);

        buttonShowResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String width = editTextWidth.getText().toString();
                String length = editTextLength.getText().toString();

                Intent intent = new Intent(MainActivity.this, ResultActivityy.class);
                intent.putExtra("WIDTH", width);
                intent.putExtra("LENGTH", length);
                startActivity(intent);
            }
        });
    }
}