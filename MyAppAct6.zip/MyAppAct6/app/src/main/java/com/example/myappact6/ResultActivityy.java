package com.example.myappact6;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivityy extends AppCompatActivity {

    TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_activityy);

        textViewResult = findViewById(R.id.textViewResult);

        String widthString = getIntent().getStringExtra("WIDTH");
        String lengthString = getIntent().getStringExtra("LENGTH");

        double width = Double.parseDouble(widthString);
        double length = Double.parseDouble(lengthString);
        double totalFlooring = width * length;

        String result = "Width: " + width + "\nLength: " + length + "\nTotal Flooring Needed: " + totalFlooring;
        textViewResult.setText(result);
    }
}
